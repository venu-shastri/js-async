const Router = require('koa-router');

const router = new Router();
const BASE_URL = '/api/users';

router.get(BASE_URL, async (ctx) => {
    try {
      
      ctx.body = {
        status: 'success',
        data: [{userId:'U100',name:'Tom'},{userId:'U200',name:'Hary'}]
      };
    } catch (err) {
      console.log(err)
    }
  })

  router.get(`${BASE_URL}/:id`, async (ctx) => {
    try {
      
      ctx.body = {
        status: 'success',
        data: {userId:ctx.params.id,name:'Tom'}
      };
    } catch (err) {
      console.log(err)
    }
  })


  router.post(`${BASE_URL}`, async (ctx) => {
    
      const user = await ctx.request.body;
      console.log(user);
      if (user) {
        ctx.status = 201;
        ctx.body = {
          status: 'success',
          data: user
        };
      } else {
        ctx.status = 400;
        ctx.body = {
          status: 'error',
          message: 'Something went wrong.'
        };
      }
    } 
  )

module.exports = router;