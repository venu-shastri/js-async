var config = {};

config.mongoURI = {
  development: 'mongodb://localhost/MongoDb',
  test: 'mongodb://localhost/node-test'
};

module.exports = config;
