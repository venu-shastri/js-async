const MongoClient = require('mongodb').MongoClient;
const MONGO_URL = "mongodb://localhost:27017/mongodb";
//mongodb://127.0.0.1:27017/?gssapiServiceName=mongodb


 function testMongo (app) {
    MongoClient.connect(MONGO_URL)
        .then((connection) => {
          //  app.people = connection.collection("people");
            console.log("Database connection established")
        })
        .catch((err) => console.error(err))
    }


testMongo(null);